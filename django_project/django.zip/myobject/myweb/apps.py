from django.apps import AppConfig


class MywebConfig(AppConfig):
    name = 'myweb'
